// This is a simple Hello World program in Java
public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}

# Hello World Examples

This repository contains beginner-friendly "Hello, World!" programs in both Python and Java.

## Running the Python Program
1. Ensure you have Python installed.
2. Open a terminal or command prompt.
3. Run the following command:
   ```bash
   python3 hello.py
   ```

## Running the Java Program
1. Ensure you have the Java Development Kit (JDK) installed.
2. Open a terminal or command prompt.
3. Compile the Java file using `javac`:
   ```bash
   javac Hello.java
   ```
4. Run the compiled program using `java`:
   ```bash
   java Hello
   ```
